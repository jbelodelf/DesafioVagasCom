﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VagasCom.WebUI.Models
{
    public class ConsultaOutput
    {
        public List<ConsultaModel> hits { get; set; }
    }

    public class ConsultaModel
    {
        public int Id { get; set; }
        public int NumContrato { get; set; }
        public int Codigo { get; set; }
        public string Nome { get; set; }
        public string Tipo { get; set; }
        public string NumIp { get; set; }
        public int CodUsu { get; set; }
        public string Mensagem { get; set; }
    }
}