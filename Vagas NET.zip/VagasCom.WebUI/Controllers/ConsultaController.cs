﻿using Newtonsoft.Json;
using VagasCom.Application.InterfacesApp;
using VagasCom.Domain.Entities;
using VagasCom.WebUI.Models;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace VagasCom.WebUI.Controllers
{
    public class ConsultaController : Controller
    {
        private IConsultaApp App;

        public ConsultaController(IConsultaApp _IConsultaApp)
        {
            App = _IConsultaApp;
        }

        // GET: Consulta
        public ActionResult Index()
        {
            return View();
        }

        // GET: Consulta/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Consulta/Create
        public ActionResult Create()
        {
            return View();
        }

        //[HttpPost]
        public ActionResult create(ConsultaModel model)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:1495/api/login/model");

                //HTTP POST
                var postTask = client.PostAsJsonAsync<ConsultaModel>("model", model);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Por favor, contate o administrador.");
            ConsultaEntity entity = new ConsultaEntity();

            return View(entity);
        }

        // GET: Consulta/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Consulta/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Consulta/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Consulta/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }

}
