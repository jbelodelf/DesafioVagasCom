﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Vagas.Domain.ConvertFunctions;
using VagasCom.Domain.Entities;

namespace VagasCom.Test
{
    [TestClass]
    public class ConvertRomanTest
    {
        [TestMethod]
        public void TestConvertNumbers()
        {
            ConvertionsMethods ConvertionsMethods = new ConvertionsMethods();

            //Arrange
            string expected = "LXXVDCCCX";
            int numerator = 75810;

            //Act
            string actual = ConvertionsMethods.ConvertNumbers(numerator);

            //Assert
            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestConvertRoman() 
        {
            ConvertionsMethods ConvertionsMethods = new ConvertionsMethods();

            //Arrange
            int expected = 3999;
            string numerator = "MMMCMXCIX";

            //Act
            int actual = ConvertionsMethods.ConvertRoman(numerator);

            //Assert
            Assert.AreEqual(expected, actual);
        }

    }
}
