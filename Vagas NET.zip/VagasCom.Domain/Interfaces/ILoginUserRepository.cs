﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SigsmEsus.Domain.Entities;

namespace SigsmEsus.Domain.Interfaces
{
    public interface ILoginUserRepository : IGenericRepository<LoginUserEntity>
    {
        LoginUserEntity ConsultaLoginUser();
    }
}
