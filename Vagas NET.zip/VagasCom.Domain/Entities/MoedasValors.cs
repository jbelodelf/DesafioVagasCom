﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VagasCom.Domain.Entities
{
    public class MoedasValors
    {
        public int Id { get; set; }
        public string Moeda { get; set; }
        public string ValorRomano { get; set; }
        public decimal Credito { get; set; }
    }
}
