﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VagasCom.Domain.Entities
{
    [Table("ConsultaTeste", Schema = "ado")]
    public class ConsultaEntity
    {
        [Key]
        public int Id { get; set; }
        public int NumContrato { get; set; }
        public int Codigo { get; set; }
        public string Nome { get; set; }
        public string Tipo { get; set; }
        public string NumIp { get; set; }
        public int CodUsu { get; set; }
    }
}
