﻿using System;
using System.Collections.Generic;
using VagasCom.Domain.Entities;

namespace Vagas.Domain.ConvertFunctions
{
    public class ConvertionsMethods
    {
        //Metodo responsável em converter número inteiro para algarismo romano
        public string ConvertNumbers(int num)
        {
            string row = "";

            #region Laço
            while (true)
            {
                if (num < 1000000 && num > 99999)
                {
                    switch (num / 100000)
                    {
                        case 1: row += "C"; break;
                        case 2: row += "CC"; break;
                        case 3: row += "CC"; break;
                        case 4: row += "CD"; break;
                        case 5: row += "D"; break;
                        case 6: row += "DC"; break;
                        case 7: row += "DCC"; break;
                        case 8: row += "DCCC"; break;
                        case 9: row += "CM"; break;
                    }
                    num -= 100000 * (num / 100000);
                }

                else if (num < 100000 && num > 9999)
                {
                    switch (num / 10000)
                    {
                        case 1: row += "X"; break;
                        case 2: row += "XX"; break;
                        case 3: row += "XXX"; break;
                        case 4: row += "XL"; break;
                        case 5: row += "L"; break;
                        case 6: row += "LX"; break;
                        case 7: row += "LXX"; break;
                        case 8: row += "LXXX"; break;
                        case 9: row += "XC"; break;
                    }
                    num -= 10000 * (num / 10000);
                }
                //--------------------------------------
                else if (num < 10000 && num > 999)
                //if (num < 1000 && num > 999)
                {
                    switch (num / 1000)
                    {
                        case 1: row += "M"; break;
                        case 2: row += "MM"; break;
                        case 3: row += "MMM"; break;
                        case 4: row += "IV"; break;
                        case 5: row += "V"; break;
                        case 6: row += "VI"; break;
                        case 7: row += "VII"; break;
                        case 8: row += "VIII"; break;
                        case 9: row += "IX"; break;
                    }
                    num -= 1000 * (num / 1000);
                }
                else if (num < 1000 && num > 99)
                {
                    switch (num / 100)
                    {
                        case 1: row += "C"; break;
                        case 2: row += "CC"; break;
                        case 3: row += "CC"; break;
                        case 4: row += "CD"; break;
                        case 5: row += "D"; break;
                        case 6: row += "DC"; break;
                        case 7: row += "DCC"; break;
                        case 8: row += "DCCC"; break;
                        case 9: row += "CM"; break;
                    }
                    num -= 100 * (num / 100);
                }
                else if (num < 100 && num > 9)
                {
                    switch (num / 10)
                    {
                        case 1: row += "X"; break;
                        case 2: row += "XX"; break;
                        case 3: row += "XXX"; break;
                        case 4: row += "XL"; break;
                        case 5: row += "L"; break;
                        case 6: row += "LX"; break;
                        case 7: row += "LXX"; break;
                        case 8: row += "LXXX"; break;
                        case 9: row += "XC"; break;
                    }
                    num -= 10 * (num / 10);
                }
                else if (num < 10 && num > 0)
                {
                    switch (num)
                    {
                        case 1: row += "I"; break;
                        case 2: row += "II"; break;
                        case 3: row += "II"; break;
                        case 4: row += "IV"; break;
                        case 5: row += "V"; break;
                        case 6: row += "VI"; break;
                        case 7: row += "VII"; break;
                        case 8: row += "VIII"; break;
                        case 9: row += "IX"; break;
                    }
                    num -= num;
                }
                else
                {
                    row = "I have no idea what you are talking about";
                    break;
                }
                if (num == 0)
                    break;

            }
            #endregion

            return row;
        }

        //Metodo responsável em converter algarismo romano em número inteiro 
        public int ConvertRoman(string num)
        {
            #region Monta o Array
            string[] Numeracao = new string[100];

            for (int i = 0; i < num.Length; i++)
            {
                if (!String.IsNullOrEmpty(num.Substring(i, 1)))
                {
                    Numeracao[i] = num.Substring(i, 1);
                }
                else
                {
                    Numeracao[i] = "";
                }
            }
            #endregion

            int valorFinal = 0;

            for (int i = 0; i < Numeracao.Length; i++)
            {
                if (Numeracao[i] != null)
                {
                    #region Valida se tem algarismo errado
                    string Numeracao1 = "";
                    string Numeracao2 = "";
                    string Numeracao3 = "";
                    string Numeracao4 = "";

                    if (Numeracao[i] != null)
                        Numeracao1 = Numeracao[i].ToUpper();
                    if (Numeracao[i + 1] != null)
                        Numeracao2 = Numeracao[i + 1].ToUpper();
                    if (Numeracao[i + 2] != null)
                        Numeracao3 = Numeracao[i + 2].ToUpper();
                    if (Numeracao[i + 3] != null)
                        Numeracao4 = Numeracao[i + 3].ToUpper();

                    if (Numeracao1 == Numeracao2 && Numeracao2 == Numeracao3 && Numeracao3 == Numeracao4)
                    {
                        valorFinal = -1;
                        break;
                    }

                    if (Numeracao1 == "V" && Numeracao2 == "V" || Numeracao1 == "L" && Numeracao2 == "L" || Numeracao1 == "D" && Numeracao2 == "D")
                    {
                        valorFinal = -1;
                        break;
                    }
                    #endregion

                    var valorDig1 = Valor(Numeracao1);
                    var valorDig2 = Valor(Numeracao2);

                    if (valorDig1 != 0)
                    {
                        if (valorDig1 < valorDig2)
                        {
                            var valido = false;
                            if (valorDig1 == 100 && valorDig2 == 1000 || valorDig1 == 100 && valorDig2 == 500)
                            {
                                valido = true;
                            }
                            else if (valorDig1 == 10 && valorDig2 == 100 || valorDig1 == 10 && valorDig2 == 50)
                            {
                                valido = true;
                            }
                            else if (valorDig1 == 1 && valorDig2 == 10 || valorDig1 == 1 && valorDig2 == 5)
                            {
                                valido = true;
                            }

                            if (valido)
                            {
                                valorFinal += +(valorDig2 - valorDig1);
                                i += 1;
                            }
                            else
                            {
                                valorFinal = -1;
                                break;
                            }
                        }
                        else
                        {
                            valorFinal += +valorDig1;
                        }
                    }
                    else
                    {
                        valorFinal = -1;
                        break;
                    }
                }
                else
                {
                    break;
                }
            }

            return valorFinal;
        }

        //Metodo responsável em conversão dos valores 
        private int Valor(string algarismo)
        {
            int retorna = 0;

            switch (algarismo)
            {
                case "M":
                    retorna = 1000;
                    break;
                case "D":
                    retorna = 500; 
                    break;
                case "C":
                    retorna = 100;
                    break;
                case "L":
                    retorna = 50;
                    break;
                case "X":
                    retorna = 10;
                    break;
                case "V":
                    retorna = 5;
                    break;
                case "I":
                    retorna = 1;
                    break;
                default:
                    retorna = 0;
                    break;
            }
            return retorna;
        }
    }
}
