﻿using VagasCom.Application.InterfacesApp;
using VagasCom.Domain.Entities;
using VagasCom.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VagasCom.Application.RepositoriesApp
{
    public class ColsultaRepositoryApp : IConsultaApp
    {
        IConsultaRepository _IConsultaRepository;

        public ColsultaRepositoryApp(IConsultaRepository repository)
        {
            _IConsultaRepository = repository;
        }

        public List<ConsultaEntity> ListaConsulta(string login)
        {
            return _IConsultaRepository.ListaConsulta(login);
        }

        public IEnumerable<ConsultaEntity> ListAll()
        {
            return _IConsultaRepository.ListAll().ToList();
        }

        public ConsultaEntity Find(int Id)
        {
            return _IConsultaRepository.Find(Id);
        }

        public void Add(ConsultaEntity entity)
        {
            _IConsultaRepository.Add(entity);
        }

        public void UpDate(ConsultaEntity entity)
        {
            _IConsultaRepository.UpDate(entity);
        }

        public void Delete(ConsultaEntity entity)
        {
            _IConsultaRepository.Delete(entity);
        }
    }
}
