﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SigsmEsus.Application.InterfacesApp;
using SigsmEsus.Domain.Entities;
using SigsmEsus.Domain.Interfaces;

namespace SigsmEsus.Application.RepositoriesApp
{
    public class LoginUserRepositoryApp : ILoginUserApp
    {
        private ILoginUserRepository Repository;

        public LoginUserRepositoryApp(ILoginUserRepository _ILoginUserRepository)
        {
            Repository = _ILoginUserRepository;
        }

        public void Add(LoginUserEntity entity)
        {
            throw new NotImplementedException();
        }

        public LoginUserEntity ConsultaLoginUser()
        {
            return Repository.ConsultaLoginUser();
        }

        public void Delete(LoginUserEntity entity)
        {
            throw new NotImplementedException();
        }

        public IQueryable<LoginUserEntity> Fetch()
        {
            throw new NotImplementedException();
        }

        public LoginUserEntity Find(int Id)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<LoginUserEntity> ListAll()
        {
            throw new NotImplementedException();
        }

        public void UpDate(LoginUserEntity entity)
        {
            throw new NotImplementedException();
        }
    }
}
