﻿using SigsmEsus.Domain.Entities;

namespace SigsmEsus.Application.InterfacesApp
{
    public interface ILoginUserApp : IGenericApp<LoginUserEntity>
    {
        LoginUserEntity ConsultaLoginUser();
    }
}
