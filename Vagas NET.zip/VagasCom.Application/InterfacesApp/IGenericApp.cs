﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VagasCom.Application.InterfacesApp
{
    public interface IGenericApp<T> where T : class
    {
        IEnumerable<T> ListAll();
        T Find(int Id);
        void Add(T entity);
        void UpDate(T entity);
        void Delete(T entity);
    }
}
