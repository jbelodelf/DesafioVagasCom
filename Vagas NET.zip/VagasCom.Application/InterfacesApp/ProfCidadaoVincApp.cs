﻿using SigsmEsus.Application.InterfacesApp;
using SigsmEsus.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SigsmEsus.Application.InterfacesApp
{
    public interface ProfCidadaoVincApp : IGenericApp<ProfCidadaoVincEntity>
    {
        void DeleteProfCidadao(int id);

        ProfCidadaoVincEntity BuscaProfCidadaoVinc(int IdProfissional, int IdCidadao);
    }
}
