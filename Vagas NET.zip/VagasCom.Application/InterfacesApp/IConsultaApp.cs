﻿using VagasCom.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VagasCom.Application.InterfacesApp
{
    public interface IConsultaApp : IGenericApp<ConsultaEntity>
    {
        List<ConsultaEntity> ListaConsulta(string login);
    }
}
