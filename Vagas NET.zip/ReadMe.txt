ReadMe

Este projeto foi desenvolvido em uma arquitetura DDD. Embora n�o tenha implementado o uso de banco da dados, 
criei todos os m�todos para poss�vel implementa��o futura, todas as classes gen�ricas e inje��o de depend�ncia com Unity. 
Toda a estrutura bem separado, com as camadas de Apresention, Application, Domain, InfraStruture e TDD.

Dentro da camada Domain, foi criado a pasta "ConvertFunctions" onde cont�m as metodos ConvertNumbers(int num) e 
ConvertRoman(string num). O primeiro tem a fun��o de converter os valores 
recebido em Cr�dito e transformar em algarismo romano. O segundo, mesmo n�o sendo utilizando para este projeto, tem a 
func��o de converte algarismo romana em numero inteiro com limite de 3999.

COMO UTILIZAR ESTE PROJETO:
Na pasta "0-Presentation", "ConsoleApplication" foi criado um projeto de Console Application com o nome de VagasCom.ConsoleUI, 
e na pasta da aplica��o em "DesafioVagasCom\Arquivos" contem dois arquivos TXT, um de nome "Moeda.txt" que contem a descri��o das moeda e seus 
valores e outro "Table Input.txt" que ser� usado como arquivo de entrada, contendo as moedas a serem convertidas.

A ESTRUTURA DOS ARQUIVOS:
O arquivo Moeda.txt 
	� composto de quatro colunas, sendo a promeira o ID, a segundo NOME DA MOEDA, a terceira VALOR ROMANO e a quarta VALOR EM CR�DITO, 
todas as colunas separadas por espa�o branco.

O Table Input.txt
	� composto por linhas sem uma estrutura pr� definida, podendo ser composta por texto livre com o nome de cada mo�da separada por um espa�o
em branco.

EXECU��O:
Ao excutar a aplica��o, informar o nome do arquivo de entrado no console >Table Input.txt, a aplica��o ir� realizar a leitura e listar o resultado.