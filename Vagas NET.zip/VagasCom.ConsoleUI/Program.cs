﻿using System;
using System.Collections.Generic;
using System.Linq;
using Vagas.Domain.ConvertFunctions;
using VagasCom.Domain.Entities;

namespace VagasCom.ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            //Model creado para arqmazenar os dados do arquivo de Moeda.txt
            List<MoedasValors> ListaMoedasValors = new List<MoedasValors>();

            //Instância da class onde estão os métodos de conversão.
            ConvertionsMethods ConvertionsMethods = new ConvertionsMethods();
            string fileName = "";

            Console.Write("Entry the file name: ");
            fileName = Console.ReadLine();

            #region Leitura dos arquivo TXT
            //Arquivo de moeda
            string[] lines = System.IO.File.ReadAllLines(@"C:\DesafioVagasCom\Arquivos\Moeda.txt");
            foreach (string line in lines)
            {
                var textLine = line.Split();
                ListaMoedasValors.Add(new MoedasValors()
                {
                    Id = Convert.ToInt32(textLine[0]),
                    Moeda = textLine[1],
                    ValorRomano = textLine[2],
                    Credito = Convert.ToInt64(textLine[3])
                });
            }

            //Arquivo de entrada
            string[] linesImput = System.IO.File.ReadAllLines(@"C:\DesafioVagasCom\Arquivos\" + fileName);
            foreach (string line in linesImput)
            {
                //Soma dos crédito
                decimal totalCredito = 0;
                //Concatenar os nomes das moedas a serem convertidas
                string name = "";

                //Cria array para identificar os nomes das moedas
                var lineSprit = line.Split();
                //Varredura do array de moedas
                foreach (var moeda in lineSprit)
                {
                    //Localiza a moeda na model carregada
                    var valorRomano = ListaMoedasValors.Find(t => t.Moeda.ToUpper().Trim() == moeda.ToUpper().Trim());
                    if (valorRomano != null)
                    {
                        //Adiciona o valor de crédito da moeda à variável credito
                        var credito = valorRomano.Credito;
                        //Soma o valor do credito
                        totalCredito += credito;
                        //Concatena o nome da moeda
                        name += moeda + " ";
                    }
                }

                //Converte os créditos em valor Romano
                var numRomano = ConvertionsMethods.ConvertNumbers(Convert.ToInt32(totalCredito));
                //Retorna o resultada da linha e mostra na console
                if (numRomano.Length > 30)
                    Console.WriteLine("\t" + numRomano);
                else
                    Console.WriteLine("\t" + name + " is " + totalCredito + " Credits and Roman numbers is " + numRomano);
            }

            //Aguarda uma tecla ser pressionada para fechar a console
            Console.WriteLine("Press any key to exit.");
            System.Console.ReadKey();
            #endregion
        }
    }
}
