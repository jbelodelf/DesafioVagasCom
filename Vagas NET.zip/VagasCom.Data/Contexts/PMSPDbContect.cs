﻿using VagasCom.Data.Mapping;
using VagasCom.Domain.Entities;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace VagasCom.Data.Contexts
{
    public class PMSPDbContect : DbContext
    {
        public PMSPDbContect()
            : base("PMSPDbConection")
        {
            Database.SetInitializer<PMSPDbContect>(null);
            Database.CommandTimeout = 60;
        }
         
        public DbSet<ConsultaEntity> Consulta { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            modelBuilder.Conventions.Remove<OneToManyCascadeDeleteConvention>();
            modelBuilder.Conventions.Remove<ManyToManyCascadeDeleteConvention>();

            modelBuilder.Properties()
                .Where(p => p.Name == p.ReflectedType.Name + "Id")
                .Configure(p => p.IsKey());

            modelBuilder.Configurations.Add(new ConsultaMap());
        }
    }
}
