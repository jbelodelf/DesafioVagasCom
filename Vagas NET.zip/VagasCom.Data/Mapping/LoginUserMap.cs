﻿using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SigsmEsus.Domain.Entities;

namespace SigsmEsus.Data.Mapping
{
    class LoginUserMap : EntityTypeConfiguration<LoginUserEntity>
    {
        public LoginUserMap()
        {
            HasKey(t => t.ID);
            Property(t => t.Login);
        }
    }
}
