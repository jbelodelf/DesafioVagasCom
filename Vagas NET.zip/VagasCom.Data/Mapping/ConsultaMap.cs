﻿using VagasCom.Domain.Entities;
using System.Data.Entity.ModelConfiguration;

namespace VagasCom.Data.Mapping
{
    public class ConsultaMap : EntityTypeConfiguration<ConsultaEntity>
    {
        public ConsultaMap()
        {
            ToTable("ConsultaTeste");
            HasKey(t => t.Id);
            Property(t => t.NumContrato);
            Property(t => t.Codigo);
            Property(t => t.Nome);
            Property(t => t.CodUsu);
        }
    }
}
