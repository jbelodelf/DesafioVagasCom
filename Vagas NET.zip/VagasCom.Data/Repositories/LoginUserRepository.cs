﻿using System.Linq;
using SigsmEsus.Domain.Entities;
using SigsmEsus.Domain.Interfaces;
using SigsmEsus.Data.Contexts;

namespace SigsmEsus.Data.Repositories
{
    public class LoginUserRepository : GenericRepository<LoginUserEntity>, ILoginUserRepository
    {
        PMSPDbContect dbPmspDbContext = new PMSPDbContect();

        public LoginUserEntity ConsultaLoginUser()
        {
            return null; //dbPmspDbContext.LoginUserEntity.FirstOrDefault();
        }
    }
}
