﻿using VagasCom.Data.Contexts;
using VagasCom.Domain.Entities;
using VagasCom.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;

namespace VagasCom.Data.Repositories
{
    public class ConsultaRepository : GenericRepository<ConsultaEntity>, IConsultaRepository
    {
        public List<ConsultaEntity> ListaConsulta(string login)
        {
            try
            {
                string SQLQUERY = "SELECT Distinct top 1 ptu.CodUsuario, ptu.Login, ptu.Senha, prof.CNS, peu.INE, esp.CBO, peu.CodUnidade as CNES";
                SQLQUERY += @" FROM [PtUsuario] ptu with (nolock)";
                SQLQUERY += @" Inner Join [Profissionais] prof with(nolock) on ptu.CPF = prof.CPF";
                SQLQUERY += @" Inner Join [ProfXEspXUnid] peu with(nolock) on prof.Matricula = peu.Matricula";
                SQLQUERY += @" Inner Join [Especialidades] esp with(nolock) on peu.CodEspecialidade = esp.CodEspecialidade";
                SQLQUERY += " Where ptu.Login = '" + login + "'";

                using (var Base = new PMSPDbContect())
                {
                    return Base.Database.SqlQuery<ConsultaEntity>(SQLQUERY).ToList();
                }
            }
            catch (Exception)
            {
                return new List<ConsultaEntity>();
            }
        }
    }
}
